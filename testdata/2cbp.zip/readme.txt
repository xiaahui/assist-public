Each instance CL_X_N_Z.TXT is defined by
- a class X (X = 1, 2, ..., 10);
- the number N of items (N = 25, 50, 100, 200 for classes 1 to 9,
			 N = 24, 51,  99, 201 for class 10);
- an identifier Z (Z = 1, 2, ..., 10).

For each instance we report:
- the number N of items;
- the weight and volume capacity of the bin;
- N lines, each indicating, for each item, a progressive index,
  the weight and the volume.